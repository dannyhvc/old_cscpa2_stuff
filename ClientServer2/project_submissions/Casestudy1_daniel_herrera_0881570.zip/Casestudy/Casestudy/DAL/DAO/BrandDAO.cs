﻿using Casestudy.DAL.DomainClasses;
using Casestudy.DAL;
using Microsoft.EntityFrameworkCore;


namespace Casestudy.DAL.DAO
{
    public class BrandDAO
    {
        private readonly AppDbContext _db;
        public BrandDAO(AppDbContext ctx)
        {
            _db = ctx;

        }
        public async Task<List<Brand>> GetAll()
        {
            return await _db.Brands!.ToListAsync();
        }
    }
}