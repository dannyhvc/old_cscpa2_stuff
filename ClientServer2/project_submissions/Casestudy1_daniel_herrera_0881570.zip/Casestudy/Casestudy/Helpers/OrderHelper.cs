﻿namespace Casestudy.Helpers
{
    public class OrderHelper
    {
        public string? Email { get; set; }
        public OrderItemHelper[]? Items { get; set; }
    }
}
