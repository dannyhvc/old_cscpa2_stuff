<template>
    <div class="text-center">
        <div class="text-h2 q-mt-lg">Home</div>
    </div>
</template>
