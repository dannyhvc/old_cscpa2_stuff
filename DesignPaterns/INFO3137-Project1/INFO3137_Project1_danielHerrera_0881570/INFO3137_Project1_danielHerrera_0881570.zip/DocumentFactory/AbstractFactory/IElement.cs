﻿namespace DocumentFactory
{
    public interface IElement
    {
    }
}
