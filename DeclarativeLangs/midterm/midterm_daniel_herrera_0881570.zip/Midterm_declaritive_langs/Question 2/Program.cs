﻿using Question_2.frontend;

namespace Question_2
{
    public class Program
    {
        static void Main(string[] args) => new RecipeConsole().Run();
    }
}
